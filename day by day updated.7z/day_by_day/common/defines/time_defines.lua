NDefines.NCountry.EVENT_PROCESS_OFFSET = 1 --Было 20	
NDefines.NCountry.DAYS_OF_WAR_BEFORE_SURRENDER = 1 -- 7


NDefines.NTechnology.BASE_RESEARCH_POINTS_SAVED = 1.25 --30.0
NDefines.NTechnology.BASE_YEAR_AHEAD_PENALTY_FACTOR = 2 --2
NDefines.NTechnology.BASE_TECH_COST = 3.54 --85

NDefines.NFocus.FOCUS_POINT_DAYS = 0.5 --Было 10
NDefines.NFocus.MAX_SAVED_FOCUS_PROGRESS = 0 --Было 10





NDefines.NMilitary.LAND_SPEED_MODIFIER = 1.2 --0.05
NDefines.NMilitary.STRATEGIC_SPEED_BASE = 240.0 --10.0